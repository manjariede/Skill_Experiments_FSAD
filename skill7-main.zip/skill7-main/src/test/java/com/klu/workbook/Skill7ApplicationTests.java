package com.klu.workbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Skill7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
