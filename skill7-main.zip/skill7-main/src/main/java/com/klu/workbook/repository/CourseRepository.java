package com.klu.workbook.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.klu.workbook.model.Course;

public interface CourseRepository extends JpaRepository<Course, Integer> {

    List<Course> findByTitle(String title);

}